package com.bean;

public class AnswerBean {
	
	public int questionNumber;
	public String question;
	public String selectedAnswer;
	public String correctAnswer;
	
	public AnswerBean(int questionNumber, String question, String selectedAnswer, String correctAnswer) {
		
		this.questionNumber=questionNumber;
		this.question=question;
		this.selectedAnswer=selectedAnswer;
		this.correctAnswer=correctAnswer;
	}

}
