package com.bean;

public class SubjectBean {
	
	String newSubject;

	public String getNewSubject() {
		return newSubject;
	}

	public void setNewSubject(String newSubject) {
		this.newSubject = newSubject;
	}

	
	
	

}
