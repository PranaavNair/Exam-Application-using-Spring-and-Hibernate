package com.database;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.bean.AdminBean;
import com.bean.QuestionBean;
import com.bean.UserBean;

public class AdminDao {
	
	HibernateTemplate template;
	
	public void setTemplate(HibernateTemplate template) {
		this.template=template;
	}
	
	public HibernateTemplate getTemplate() {
		return template;
	}
	
	public void insertNewAdmin(AdminBean ab) {
		
		template.save(ab);
	}
	
	public boolean adminVerification(String adminId, String adminPassword) {
		
		AdminBean adminbean=template.get(AdminBean.class, adminId);
		
		if(adminbean==null)
			return false;
		if(adminId.equals(adminbean.getEmail_id()) && adminPassword.equals(adminbean.getPassword())) {
			
				return true;
			
		}
		return false;
	}
	

}
