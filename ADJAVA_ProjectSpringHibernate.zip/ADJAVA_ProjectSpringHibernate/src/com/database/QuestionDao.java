package com.database;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.bean.QuestionBean;

public class QuestionDao {
	
	HibernateTemplate template;

	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public void insertNewQuestion(QuestionBean qb) {
		
		template.save(qb);
	}
	
	public List viewQuestions(String category) {
		
		SessionFactory sf= template.getSessionFactory();
		Session session= sf.openSession();
		
		Query query= session.createQuery("from QuestionBean que where que.category=:category");
		query.setParameter("category",category);
		List list=query.list();
		
		return list;
	}
	
	

}
