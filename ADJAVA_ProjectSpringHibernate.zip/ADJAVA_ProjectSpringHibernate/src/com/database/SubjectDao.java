package com.database;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.bean.SubjectBean;

public class SubjectDao {
	
HibernateTemplate template;
	
	public void setTemplate(HibernateTemplate template) {
		this.template=template;
	}
	
	public HibernateTemplate getTemplate() {
		return template;
	}
	
	public void insertNewSubject(SubjectBean sub) {
		
		template.save(sub);
	}
	
	public List GetAllSubjectNames()
	{
		
		SessionFactory sf=template.getSessionFactory();
		
		Session session=sf.openSession();
		
		Query query=session.createQuery("select newSubject from SubjectBean");
		
		List subNames=query.list();
		
		return subNames;
		
		
		
		
					
	}

}
