package com.database;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.bean.AdminBean;
import com.bean.UserBean;

public class UserDao {

	HibernateTemplate template;

	public HibernateTemplate getTemplate() {
		return template;
	}

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public void insertNewUser(UserBean ub) {
			
			template.save(ub);
	}
	
	public boolean userVerification(String userId, String userPassword) {
		
		UserBean userbean=template.get(UserBean.class, userId);
		
		if(userbean==null)
			return false;
		if(userId.equals(userbean.getEmail_id()) && userPassword.equals(userbean.getPassword())) {
			
				return true;
			
		}
		return false;
	}
}
