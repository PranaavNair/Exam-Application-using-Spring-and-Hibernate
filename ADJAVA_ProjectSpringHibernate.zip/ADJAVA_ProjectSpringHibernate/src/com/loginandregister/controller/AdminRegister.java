package com.loginandregister.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bean.AdminBean;
import com.bean.QuestionBean;
import com.database.AdminDao;

@Controller
public class AdminRegister {
	
	@Autowired
	AdminDao dao;
	
	
	@RequestMapping("/AdminRegistered")
	public ModelAndView adminreg(HttpServletRequest request, HttpServletResponse response,@ModelAttribute AdminBean ab) {
		
//		Configuration c = new Configuration();
//	
//		c.configure(); // configure() will load contents hibernate configuration file into Configuration object 
//				
//		SessionFactory	 sf = c.buildSessionFactory();
//				
//		Session	 session = sf.openSession();
//		
//		Transaction tx=session.beginTransaction();
		
		//one way of creating sessionfactory object. But use this when we use only hibernate.
		//If you are integrating Spring and Hibernate use HibernateTemplate and configure it in xml file or
		//use SessionFactory which is same like HibernateTemplate and configure it in xml file
		
		//HibernateTemplate template; // Not recommended to use HibernateTemplate anymore
		
		//SessionFactory sf;
		
		//System.out.println(ab.getFirstName());									
		dao.insertNewAdmin(ab);
		
		return new ModelAndView("AdminLogin");
	
	}
	
	@RequestMapping("/OptionPage")
	public ModelAndView adminLogin(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session=request.getSession();
		response.setContentType("text/html");
		String adminId= request.getParameter("adminLoginId");
		String adminPassword= request.getParameter("adminLoginPassword");
		
		session.setAttribute("updateQue", new HashMap<Integer,QuestionBean>());
		
		if(dao.adminVerification(adminId, adminPassword)) {
			
			return new ModelAndView("Options");
		}
		else {
			
			try {
				RequestDispatcher rd= request.getRequestDispatcher("WEB-INF/jsp/AdminLogin.jsp");
				PrintWriter out = response.getWriter();
				out.print("Invalid user ID or Password");
				rd.include(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return null;
			//return new ModelAndView("AdminLogin","invalid","Invalid user ID or Password");
		
		}
		
	}
	
	

}
