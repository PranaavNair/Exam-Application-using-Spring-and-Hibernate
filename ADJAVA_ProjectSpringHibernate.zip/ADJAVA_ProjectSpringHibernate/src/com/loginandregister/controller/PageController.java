package com.loginandregister.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bean.AdminBean;

@Controller
public class PageController {
	
	//value for @RequestMapping can be anything. Not compulsory that the page we want to call and the value for @RequestMapping 
	//should be same. But the value mentioned in action attribute of form or the href value mentioned in jsp or html page
	//should be same with the value of @RequestMapping.
	//Consider we want to call abc.jsp
	
//	<form action="xyz.do">
//		<input type="submit" value="Login">
//	</form>
	
//	Then in controller class.....
//	@RequestMapping("/xyz") xyz is same as mentioned in action attribute
//	public ModelAndView Login123(HttpServletResponse response,HttpServletRequest request) {
//		return new ModelAndView("abc"); abc is the jsp or html page we want to call.
//	}
	
	@RequestMapping("/Login")
	public ModelAndView Login(HttpServletResponse response,HttpServletRequest request) {
		
		
		return new ModelAndView("Login");
	
	}
	
	@RequestMapping("/UserRegister")
	public ModelAndView UserRegister(HttpServletResponse response,HttpServletRequest request) {
		
		
		return new ModelAndView("UserRegister");
	
	}
	
	@RequestMapping("/AdminLogin")
	public ModelAndView AdminLogin(HttpServletResponse response,HttpServletRequest request) {
		
		
		return new ModelAndView("AdminLogin");
	
	}
	
	@RequestMapping("/AdminRegister")
	public ModelAndView AdminRegister(HttpServletResponse response,HttpServletRequest request) {
		
		
		return new ModelAndView("AdminRegister");
	}
	
	@RequestMapping("/Options")
	public ModelAndView AddDeleteUpdate(HttpServletRequest request, HttpServletResponse response) {
		
		return new ModelAndView("Options");
	}
	
	@RequestMapping("/QuestionAddPage")
	public ModelAndView QuestionAdd(HttpServletRequest request, HttpServletResponse response) {
		
		return new ModelAndView("QuestionAdd");
	}

	
	@RequestMapping("/QuestionDeletePage")
	public ModelAndView QuestionDelete(HttpServletRequest request, HttpServletResponse response) {
		
		return new ModelAndView("QuestionDelete");
	}
	
//	@RequestMapping("Login")
//    public String Login() {
//		
//	   			return "Login";
//  }
}
