package com.loginandregister.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bean.QuestionBean;
import com.database.QuestionDao;
import com.bean.AnswerBean;

@Controller
public class QuestionController {
	
	
	@Autowired
	QuestionDao dao;
	
	@RequestMapping("/QuestionAdd")
	public ModelAndView addNewQuestion(HttpServletRequest request, HttpServletResponse response,@ModelAttribute QuestionBean qb) {
		
//		Configuration c = new Configuration();
//	
//		c.configure(); // configure() will load contents hibernate configuration file into Configuration object 
//				
//		SessionFactory	 sf = c.buildSessionFactory();
//				
//		Session	 session = sf.openSession();
//		
//		Transaction tx=session.beginTransaction();
		
		//one way of creating sessionfactory object. But use this when we use only hibernate.
		//If you are integrating Spring and Hibernate use HibernateTemplate and configure it in xml file or
		//use SessionFactory which is same like HibernateTemplate and configure it in xml file
		
		//HibernateTemplate template; // Not recommended to use HibernateTemplate anymore
		
		//SessionFactory sf;
		
		//System.out.println(ab.getFirstName());									
		dao.insertNewQuestion(qb);
		
		return new ModelAndView("QuestionAdd");
	
	}
	
	@RequestMapping("/QuestionUpdate")
	public ModelAndView updateQuestion(HttpServletRequest request, HttpServletResponse response,@ModelAttribute QuestionBean qb) {
		
		System.out.println(request.getParameter("queNumber"));	
		System.out.println(request.getParameter("id"));	
		System.out.println(request.getParameter("que"));
		System.out.println(request.getParameter("option1"));	
		System.out.println(request.getParameter("option2"));	
		//dao.insertNewQuestion(qb);
		
		return new ModelAndView("QuestionUpdate");
	
	}
	
	@RequestMapping("/QuestionUpdatePage")
	public ModelAndView QuestionUpdate(HttpServletRequest req, HttpServletResponse res) {
		
		
		HttpSession session= req.getSession();
		String category=req.getParameter("category");
		
		session.setAttribute("queNumber",1);
		//System.out.println("Category is : "+category);
		List list= dao.viewQuestions(category);
		
		
		session.setAttribute("questions",list);
		
		return new ModelAndView("QuestionUpdate");
	}	
	
	@RequestMapping("/updateNext")
	public String UpdateNext(HttpServletRequest req, HttpServletResponse res) {
		
		int nextQuestionNumber;
		HttpSession session= req.getSession();
		String nextQuestion=req.getParameter("queNumber");
		
		if(nextQuestion=="") {
			nextQuestionNumber=0;
		}
		else {
			nextQuestionNumber=Integer.parseInt(req.getParameter("queNumber"))+1;
		}
		
		ArrayList<QuestionBean> al=(ArrayList<QuestionBean>)session.getAttribute("questions");
	
		QuestionBean question=al.get(nextQuestionNumber);
		req.setAttribute("id", question.getId());
		req.setAttribute("category", question.getCategory());
		req.setAttribute("question",question.getQuestion());
			
		req.setAttribute("option1",question.getOption1());
		
		req.setAttribute("option2",question.getOption2());
		
		req.setAttribute("option3",question.getOption3());
		
		req.setAttribute("option4",question.getOption4());
		req.setAttribute("correctAnswer", question.getCorrectAnswer());
		
		req.setAttribute("nextQuestionNumber",nextQuestionNumber);
		
		
		
//		ArrayList<QuestionBean> al=(ArrayList<QuestionBean>)session.getAttribute("questions");
//		
//		for(int i=0;i<al.size();i++) {
//			QuestionBean questionNo=al.get(i);
//			
//			//request.setAttribute("correctAnswer",questionNo.getCorrectAnswer());
//			int id=questionNo.getId();
//			String category1=questionNo.getCategory();
//			String question=questionNo.getQuestion();
//			String option1=questionNo.getOption1();
//			String option2=questionNo.getOption2();
//			String option3=questionNo.getOption3();
//			String option4=questionNo.getOption4();
//			String correctAnswer=questionNo.getCorrectAnswer();
//			//String correctAnswer= (String) request.getAttribute("correctAnswer");
//			
//			request.setAttribute("id",questionNo.getId());
//			request.setAttribute("category",questionNo.getCategory());
//			request.setAttribute("question",questionNo.getQuestion());
//			
//			request.setAttribute("option1",questionNo.getOption1());
//			
//			request.setAttribute("option2",questionNo.getOption2());
//			
//			request.setAttribute("option3",questionNo.getOption3());
//			
//			request.setAttribute("option4",questionNo.getOption4());
//			request.setAttribute("corretAnswer",questionNo.getCorrectAnswer());
//			
//			
//			
//			
//			
//			
//			HashMap<Integer, QuestionBean> hm=(HashMap<Integer, QuestionBean>)session.getAttribute("updateQue");
//			hm.put(i,new QuestionBean(id,category, question ,option1,option2,option3,option4, correctAnswer));
//			
//			session.setAttribute("updateQue",hm);
//		}
		return "QuestionUpdate";
		//return new ModelAndView("QuestionUpdate");
	}
	
	@RequestMapping("/updatePrevious")
	public String UpdatePrevious(HttpServletRequest req, HttpServletResponse res) {
		
		int nextQuestionNumber;
		HttpSession session= req.getSession();
		String nextQuestion=req.getParameter("queNumber");
		
		nextQuestionNumber=Integer.parseInt(req.getParameter("queNumber"))-1;
		
		ArrayList<QuestionBean> al=(ArrayList<QuestionBean>)session.getAttribute("questions");
	
		QuestionBean question=al.get(nextQuestionNumber);
		req.setAttribute("id", question.getId());
		req.setAttribute("category", question.getCategory());
		req.setAttribute("question",question.getQuestion());
			
		req.setAttribute("option1",question.getOption1());
		
		req.setAttribute("option2",question.getOption2());
		
		req.setAttribute("option3",question.getOption3());
		
		req.setAttribute("option4",question.getOption4());
		req.setAttribute("correctAnswer", question.getCorrectAnswer());
		
		req.setAttribute("nextQuestionNumber",nextQuestionNumber);
		
		return "QuestionUpdate";
		//return new ModelAndView("QuestionUpdate");
	}
	
	@RequestMapping("/ViewQuestions")
	public void viewQuestions(HttpServletRequest req, HttpServletResponse response, @ModelAttribute QuestionBean qb) throws IOException {
		
		HttpSession session= req.getSession();
		String category=(String)session.getAttribute("category");
		
		List list= dao.viewQuestions(category);
		
		
		session.setAttribute("questions",list);
		
		//session.setAttribute("numberabc", 0);

		session.setAttribute("queNumber",0);
		session.setAttribute("score",1);
		
		System.out.println(list);

//		
//		int nextQuestionNumber;
//		//System.out.println("called next");
//		
//		//HttpSession session=req.getSession();
//		String nextQuestion=req.getParameter("queNumber");
//	
//		if(nextQuestion=="") {
//			nextQuestionNumber=1;
//		}
//		else {
//			nextQuestionNumber=Integer.parseInt(req.getParameter("queNumber"))+1;
//		}
//		
//		//System.out.println("value from jsp:"+nextQuestionNumber);
//		
//		ArrayList<QuestionBean> al=(ArrayList<QuestionBean>)session.getAttribute("questions");
////		System.out.println("ARRAYLIST SIZE : "+al.size());
//		session.setAttribute("arraylistSize", al.size()-1 );
//		QuestionBean question=al.get(nextQuestionNumber);
//		
//		req.setAttribute("question",question.getQuestion());
//			
//		req.setAttribute("option1",question.getOption1());
//		
//		req.setAttribute("option2",question.getOption2());
//		
//		req.setAttribute("option3",question.getOption3());
//		
//		req.setAttribute("option4",question.getOption4());
//		
//		req.setAttribute("nextQuestionNumber",nextQuestionNumber);
//		
//		return "Exam";
//		
//		
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/next")
	public String next(HttpServletRequest req,HttpServletResponse res)
	{
		int nextQuestionNumber;
		//System.out.println("called next");
		
		HttpSession session=req.getSession();
		String nextQuestion=req.getParameter("queNumber");
	
		if(nextQuestion=="") {
			nextQuestionNumber=1;
		}
		else {
			nextQuestionNumber=Integer.parseInt(req.getParameter("queNumber"))+1;
		}
		
		//System.out.println("value from jsp:"+nextQuestionNumber);
		
		ArrayList<QuestionBean> al=(ArrayList<QuestionBean>)session.getAttribute("questions");
//		System.out.println("ARRAYLIST SIZE : "+al.size());
		session.setAttribute("arraylistSize", al.size()-1 );
		QuestionBean question=al.get(nextQuestionNumber-1);
		
		req.setAttribute("question",question.getQuestion());
			
		req.setAttribute("option1",question.getOption1());
		
		req.setAttribute("option2",question.getOption2());
		
		req.setAttribute("option3",question.getOption3());
		
		req.setAttribute("option4",question.getOption4());
		
		req.setAttribute("nextQuestionNumber",nextQuestionNumber);
		
		return "Exam";
		
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/previous")
	public String previous(HttpServletRequest req,HttpServletResponse res)
	{
		
		HttpSession session=req.getSession();
		String nextQuestion=req.getParameter("queNumber");
		
		int nextQuestionNumber=Integer.parseInt(req.getParameter("queNumber"))-1;
		
		System.out.println("value from jsp:"+nextQuestionNumber);
		
		ArrayList<QuestionBean> al=(ArrayList<QuestionBean>)session.getAttribute("questions");
	
		QuestionBean question=al.get(nextQuestionNumber-1);
		
		req.setAttribute("question",question.getQuestion());
			
		req.setAttribute("option1",question.getOption1());
		
		req.setAttribute("option2",question.getOption2());
		
		req.setAttribute("option3",question.getOption3());
		
		req.setAttribute("option4",question.getOption4());
		
		req.setAttribute("nextQuestionNumber",nextQuestionNumber);
		
		return "Exam";
		
	}

	
	@SuppressWarnings("unchecked")
	@RequestMapping("/submitAnswer")
	public void submitAnswer(HttpServletRequest req,HttpServletResponse res)
	{
		System.out.println("Answer Submitted");
		HttpSession session=req.getSession();
		
		String question=req.getParameter("question");
		
		String selectedAnswer=req.getParameter("selectedAnswer");
		int queNumber=Integer.parseInt(req.getParameter("queNumber"));
		System.out.println("queNumber is : "+queNumber);
		
		ArrayList<QuestionBean> al=(ArrayList<QuestionBean>)session.getAttribute("questions");
		
		QuestionBean questionNo=al.get(queNumber);
		
		req.setAttribute("correctAnswer",questionNo.getCorrectAnswer());
		String correctAnswer= (String) req.getAttribute("correctAnswer");
		
		//System.out.println("Submitted Answer :- " + selectedAnswer + "Original Answer :- " + req.getAttribute("correctAnswer"));
		
		HashMap<Integer, AnswerBean> hm=(HashMap<Integer, AnswerBean>)session.getAttribute("recordedAnswers");
		hm.put(queNumber ,new AnswerBean(queNumber, question , selectedAnswer, correctAnswer));
		
		session.setAttribute("recordedAnswers",hm);
		
	}
	
	@RequestMapping("/examresult")
	public ModelAndView examresults(HttpServletRequest request, HttpServletResponse response) {
		
		HttpSession session=request.getSession();
		HashMap<Integer, AnswerBean> hashMap=(HashMap<Integer, AnswerBean>) session.getAttribute("recordedAnswers");
		//AnswerBean ans=hashMap.get(key);
		//hashMap.size()
		//for(int i=0;i<hashMap.size();i++) {
			System.out.println("size of hashMap = "+hashMap.size());
			Collection<AnswerBean> obj=hashMap.values();
			
			for(AnswerBean ans:obj)
			{
				if(ans.selectedAnswer.equals(ans.correctAnswer)) {
					session.setAttribute("score", (Integer)session.getAttribute("score")+1);
				}
				//System.out.println(ans.selectedAnswer + " " + ans.correctAnswer);
			}
			
			//Score can also displayed in this way:
			//String score="Your Score is " + (Integer)session.getAttribute("score");
		
			//return new ModelAndView("Result","score", score);
			//Result is the page to be displayed
			//"score" is the JSTL attribute name that is used in Result page Example- ${score}
			//score is the message that is passed to the attribute in the jsp page
			
			int marks= (Integer)session.getAttribute("score");
			if(marks<5) {
				session.setAttribute("remark","POOR");
			}
			else if(marks<8) {
				session.setAttribute("remark","AVERAGE");
			}
			else if(marks<=10) {
				session.setAttribute("remark","EXCELLENT");
			}

			
		return new ModelAndView("Result");
	}
}

	
