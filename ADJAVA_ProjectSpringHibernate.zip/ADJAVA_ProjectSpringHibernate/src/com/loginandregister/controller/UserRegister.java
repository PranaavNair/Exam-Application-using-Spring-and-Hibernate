package com.loginandregister.controller;

import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bean.UserBean;
import com.bean.AnswerBean;
import com.bean.QuestionBean;
import com.database.UserDao;

@Controller
public class UserRegister {
	
	@Autowired
	UserDao dao;

	@RequestMapping("/UserRegistered")
	public ModelAndView userreg(HttpServletRequest request, HttpServletResponse response, @ModelAttribute UserBean ub) {
		
//		Configuration c = new Configuration();
//	
//		c.configure(); // configure() will load contents hibernate configuration file into Configuration object 
//				
//		SessionFactory	 sf = c.buildSessionFactory();
//				
//		Session	 session = sf.openSession();
//		
//		Transaction tx=session.beginTransaction();
		
		//one way of creating sessionfactory object. But use this when we use only hibernate.
		//If you are integrating Spring and Hibernate use HibernateTemplate and configure it in xml file or
		//use SessionFactory which is same like HibernateTemplate and configure it in xml file
		
		//HibernateTemplate template; // Not recommended to use HibernateTemplate anymore
		
		//SessionFactory sf;
		
		//System.out.println(ab.getFirstName());									
		dao.insertNewUser(ub);
		
		return new ModelAndView("Login");
	}
	
	@RequestMapping("/Exam")
	public ModelAndView adminLogin(HttpServletRequest request, HttpServletResponse response) {
		
		response.setContentType("text/html");
		String userId= request.getParameter("userLoginId");
		String userPassword= request.getParameter("userLoginPassword");
		
		if(dao.userVerification(userId, userPassword)) {
			
			String category=request.getParameter("category");
			HttpSession session= request.getSession();
			session.setAttribute("category", category);
			
			session.setAttribute("score", 0);
			session.setAttribute("recordedAnswers", new HashMap<Integer,AnswerBean>());
			
			return new ModelAndView("Exam");
		}
		else {
			
			try {
				RequestDispatcher rd= request.getRequestDispatcher("WEB-INF/jsp/Login.jsp");
				PrintWriter out = response.getWriter();
				out.print("Invalid user ID or Password");
				rd.include(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return null;
			//return new ModelAndView("AdminLogin","invalid","Invalid user ID or Password");
		
		}
		
	}
	
}
